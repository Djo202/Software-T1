/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.util.Scanner; 

import java.util.regex.Matcher; 

import java.util.regex.Pattern; 
/**
 *
 * @author 222616989
 */
 

public class ValidatePhoneNumber { 

    public static void main(String[] args) { 

        Scanner scanner = new Scanner(System.in); 

        String phoneNumber = null; 

        boolean isValid = false; 

        int attempts = 0; 

 

        while (!isValid && attempts < 3) { 

            System.out.println("Enter a phone number in the format XXX-XXX-XXXX:"); 

            phoneNumber = scanner.nextLine(); 

            isValid = validatePhoneNumber(phoneNumber); 

 

            if (!isValid) { 

                System.out.println("Invalid phone number. Please try again."); 

                attempts++; 

            } 

        } 

 
        if (isValid) { 

            displayPhoneNumberInfo(phoneNumber); 

        } else { 

            System.out.println("Number of attempts exceeded , try later"); 

        } 

        scanner.close(); 

    } 

 

    // Validate the phone number with 

    public static boolean validatePhoneNumber(String phoneNumber) { 

        String regex = "^0[6-8][1-4]-\\d{3}-\\d{4}$|^0(76|78|79)-\\d{3}-\\d{4}$"; 

        Pattern pattern = Pattern.compile(regex); 

        Matcher matcher = pattern.matcher(phoneNumber); 

        return matcher.matches(); 

    } 

    // information about the phone number 

    public static void displayPhoneNumberInfo(String phoneNumber) { 

        String code = phoneNumber.substring(0, 7); 

        String numberWithoutCode = phoneNumber.substring(4); 

        String network = determineNetwork(code); 


        System.out.println("Entered number: " + phoneNumber); 

        System.out.println("Code: " + code); 

        System.out.println("Number : " + numberWithoutCode); 

        System.out.println("Network: " + network); 

    } 

    // Determine the network based on the code 

    public static String determineNetwork(String code) { 

        char thirdDigit = code.charAt(2); 

 

        switch (thirdDigit) { 

            case '1': 
                
               
                return "Vodacom"; 
                
            case '2': 

                return "MTN"; 

            case '3': 

                return "Telkom Mobile"; 

            case '4': 

                return "Cell C"; 

            default: 

                return "Unknown Network"; 

        } 

    } 

} 