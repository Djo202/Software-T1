/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.FileWriter; 
import java.io.IOException; 
import java.util.Random; 
 
/**
 *
 * @author 222616989
 */

public class RandomNumberArray {   /**
     * @param args the command line arguments
     */

    public static void main(String[] args) { 

        int[] randomArray = generateRandomArray(20, 10, 50); 
        
        System.out.print("Generated random Array: "); 
        displayArray(randomArray); 

        int maxNonRecursive = findMaxNonRecursive(randomArray); 
        System.out.println(" The maximum Value  (Non-Recursive)is : " + maxNonRecursive); 

        int maxRecursive = findMaxRecursive(randomArray, randomArray.length); 
        System.out.println(" The maximum Value (Recursive) is : " + maxRecursive); 

        writeOutputToFile(randomArray, maxNonRecursive, maxRecursive, "output.txt"); 

    } 

    // Generate a 10 element array of random integers in the range of  1 to 50

    public static int[] generateRandomArray(int size, int min, int max) { 

        int[] array = new int[size]; 

        Random rand = new Random(); 

        for (int i = 0; i < size; i++) { 

            array[i] = rand.nextInt(max - min + 1) + min; 

        } 

        return array; 

    } 

    // Non-recursive method to find the maximum value in the array 

    public static int findMaxNonRecursive(int[] array) { 

        int max = array[0]; 

        for (int j = 1; j < array.length; j++) { 

            if (array[j] > max) { 

                max = array[j]; 

            } 

        } 

        return max; 

    } 

    // Recursive method to find the maximum value in the array 

    public static int findMaxRecursive(int[] array, int m) { 

        if (m == 1) { 

            return array[0]; 

        } 

        return Math.max(array[m - 1], findMaxRecursive(array, m- 1)); 

    } 

    // The display  of the array 

    public static void displayArray(int[] array) { 

        for (int value : array) { 

            System.out.print(value + " "); 

        } 

        System.out.println(); 

    } 

    // Write the output to a text file 

    public static void writeOutputToFile(int[] array, int maxNonRecursive, int maxRecursive, String fileName) { 

        try (FileWriter writer = new FileWriter(fileName)) { 

            writer.write("Generated Array: "); 

            for (int value : array) { 

                writer.write(value + " "); 

            } 

            writer.write("\nMaximum Value (Non-Recursive): " + maxNonRecursive); 

            writer.write("\nMaximum Value (Recursive): " + maxRecursive); 

        } catch (IOException e) { 

            System.out.println("An error occurred while writing to the file."); 


        } 

    } 

} 